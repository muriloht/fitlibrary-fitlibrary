package fitlibrary.exception;

public class AbandonException extends RuntimeException { //FitLibraryException {
	public AbandonException() {
		super("abandon");
	}
}
