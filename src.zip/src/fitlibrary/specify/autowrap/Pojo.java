/*
 * Copyright (c) 2010 Rick Mugridge, www.RimuResearch.com
 * Released under the terms of the GNU General Public License version 2 or later.
*/

package fitlibrary.specify.autowrap;

public class Pojo {
	public int identity(int i) {
		return i;
	}
}
