/*
 * @author Rick Mugridge 6/12/2003
 *
 * Copyright (c) 2003 Rick Mugridge, University of Auckland, NZ
 * Released under the terms of the GNU General Public License version 2 or later.
 *
 */
package fitbook;

/**
  *
*/
public class Occupancy2 { //COPY:ALL
	public String room, user; //COPY:ALL
	//COPY:ALL
	public Occupancy2(String room, String user) { //COPY:ALL
		this.room = room; //COPY:ALL
		this.user = user; //COPY:ALL
	} //COPY:ALL
} //COPY:ALL
