/*
 * @author Rick Mugridge 11/10/2004
 * Copyright (c) 2004 Rick Mugridge, University of Auckland, NZ
 * Released under the terms of the GNU General Public License version 2 or later.
 */
package fitbook;

/**
 * 
 */
public class UserCopy { //COPY:ALL
	public String name; //COPY:ALL
	 //COPY:ALL
	public UserCopy(String name) { //COPY:ALL
		this.name = name; //COPY:ALL
	} //COPY:ALL
} //COPY:ALL
