/*
 * @author Rick Mugridge on Dec 31, 2004
 *
 * Copyright (c) 2004 Rick Mugridge, University of Auckland, NZ
 * Released under the terms of the GNU General Public License version 2 or later.
 *
 */
package fitbook;

/**
 *
 */
@SuppressWarnings("unused")
public class TestCreditJapanese extends fitlibrary.CalculateFixture {
    public String u30AFu30ECu30B8u30C3u30C8u3092u8A31u53EFu3059u308Bu6708u6570u4FE1u983Cu5EA6u6B8Bu9AD8(
             int months, String reliable, double balance) {
        return reliable;        
    }
    public double u30AFu30ECu30B8u30C3u30C8u306Eu9650u5EA6u6708u6570u4FE1u983Cu5EA6u6B8Bu9AD8(
            int months, String reliable, double balance) {
        return balance;
    }
}
