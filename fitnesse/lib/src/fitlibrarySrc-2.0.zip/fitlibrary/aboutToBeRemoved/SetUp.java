package fitlibrary.aboutToBeRemoved;
import fitlibrary.DoFixture;

// Can delete this
public class SetUp extends DoFixture {
	public boolean testTwo() {
		return true;
	}
}
